<?php

	mysql_connect("localhost","root","17072543n");
	mysql_select_db("OCS_PANEL");
	mysql_query("SET NAMES UTF8");
	
	
 $hostname = "localhost";
 $user = "root";
 $password = "17072543n"; 
 $dbname = "OCS_PANEL"; 
?>