<?php 
$conn = mysqli_connect("localhost","root","17072543n","OCS_PANEL");

if(!$conn){
	die("Connection error: " . mysqli_connect_error());	
}
?>