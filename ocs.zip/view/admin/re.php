  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <check if="{{ @seller->id }}">
  <true>
    <section class="content-header">   
                    <h1>&nbsp;</h1>
    </section>
					</true>
                    <false>
                        <section class="content-header"></section>
                    </false>
  </check>
  <section class="content">
		<check if="{{ @message }}"> </check>
			
		<div class="row">
        <div class="col-md-6">	
			         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title">Seller Account</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->

            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
              			<div class="form-group">
                            <label>Email</label>
                            <input class="form-control" placeholder="Email" name="email" type="text" value="{{ @seller->email }}" required>
                        </div>
						<div class="form-group">
                            <label>First name</label>
                            <input class="form-control" placeholder="First name" name="firstname" type="text" value="{{ @seller->firstname }}" required>
                        </div>
						<div class="form-group">
                            <label>Last name</label>
                            <input class="form-control" placeholder="Last name" name="lastname" type="text" value="{{ @seller->lastname }}" required>
                        </div>
                         <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="username" type="text" value="{{ @seller->username }}" required>
                        </div>
                        <check if="{{ !@seller->id }}">
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="New Password" name="password" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                                <input class="form-control" placeholder="Re-enter Password" name="password_confirmation" type="password" required>
                            </div>
                        </check>
                        <div class="form-group">
                            <label>Balance</label>
                            <div class="input-group">
                                <span class="input-group-addon">RM </span>
                                <input class="form-control" placeholder="100" name="saldo" type="number" step="1" value="{{ @seller->saldo }}" required>
                            </div>
                        </div>
						
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
                        <check if="{{ @seller->id }}">
                            <true>
                                <check if="{{ @seller->active==1 }}">
                                    <true>
                                        <a href="{{ @URI.'/active/0' }}" class="btn btn-warning">Locked</a>
                                    </true>
                                    <false>
                                        <a href="{{ @URI.'/active/1' }}" class="btn btn-success">Unlocked</a>
                                    </false>
                                </check>
                                <a href="{{ @URI.'/delete' }}" class="btn btn-danger hapus">Delete</a>
                            </true>
                            <false>
                                <a href="/home/admin/seller" class="btn btn-default">Back</a>
                            </false>
                        </check>
				              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>

       <check if="{{ @seller->id }}">		  
        <div class="col-md-6">		  
         <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">Change Password</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="{{ @URI }}" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="/home/admin/seller" class="btn btn-default pull-right"><i class="fa fa-arrow-left fa-fw"></i> Back</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
</check>
		  
          </div>		  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->