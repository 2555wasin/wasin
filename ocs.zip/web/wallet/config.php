<?php
$host = 'localhost';
$user = 'root'; //user database
$pass = '17072543n'; //pass database
$db = 'OCS_PANEL'; //database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con,'utf8');