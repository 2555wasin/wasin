<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="http://45.76.148.251/web/favicon.ico">
  <title>NIRAN-VPN</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.rawgit.com/suryadewa/Website/b1fd0e05/blue.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
   /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 15px;
    }
	    .bs-example{
    	margin: 15px;
    }
  </style>
</head> 
<?php
SESSION_START();
include 'config.php';

$user = $_POST['user'];

$sql = "select * from users where username='$user'";
$query = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($query);
if(isset($result)){
	$_SESSION['user'] = $result;
	header("location: user.php");
}else{
	echo ' <br><p><center><font color="red" size="24"><h3>!! �ô�����ͼ����ҹ���١��ͧ !!</h3></font></p>
<p><a href="/web/wallet/"><font size="24"><h3><u>��͹��Ѻ</u></h3></font></a></center></p> ';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="http://45.76.148.251/web/favicon.ico">
  <title>NIRAN-VPN</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.rawgit.com/suryadewa/Website/b1fd0e05/blue.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
   /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 15px;
    }
	    .bs-example{
    	margin: 15px;
    }
  </style>
</head> 
