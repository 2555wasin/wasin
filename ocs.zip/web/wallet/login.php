<html>
<html lang="en">
	<head>
	<LINK REL="SHORTCUT ICON" HREF="http://mmt-server.tk/images/vpn.png">
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		<title>MMT-VPN.GA</title>
		<!-- core CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		
		<link href="http://smile-vpn.net/asset/css/sb-admin-2.css" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?= base_url('asset/js/html5shiv.js');?>"></script>
		<script src="<?= base_url('asset/js/respond.min.js');?>"></script>
		<![endif]-->
		<link rel="shortcut icon" href="<?= base_url('images/ico/favicon.ico')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?= base_url('images/ico/apple-touch-icon-144-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?= base_url('images/ico/apple-touch-icon-114-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?= base_url('images/ico/apple-touch-icon-72-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" href="<?= base_url('images/ico/apple-touch-icon-57-precomposed.png')?>"/>
	</head>
<body>
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-4 col-md-offset-4 ver-center">
<form action="check.php" method="post">
	<div class="form-group">
		<h2>ชื่อผู้ใช้งาน(Username)</h2>
		<input type="text" class="form-control" name="user">
	</div>
         <button class="btn btn-block btn btn-warning" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> เข้าสู่ระบบ</button>
		<a href="http://mmt-server.tk/MMT-VPN/" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                   ย้อนกลับ</a>
	</div>
</form>
</div> 
<p>truemoney wallet auto เพียงแค่นำหมายเลขอ้างอิงมาใส่</p>
<p>เบอร์ wallet:0946255482 (สุทิศา คงคิรินทร์)</p>
<p>กฎการเติมเงิน ห้ามเติมต่ำกว่า10 บาทไม่งั้นระบบจะไม่นำเครดิตเข้าให้</p>
<p>ราคาที่เติม 10 =10 เครดิต</p>
<p>ราคาที่เติม 20 =20 เครดิต</p>
<p>ราคาที่เติม 30 =30 เครดิต</p>
<p>ราคาที่เติม 40 =40 เครดิต</p>
<p>ราคาที่เติม 50 =50 เครดิต</p>
<p>&nbsp;</p>
</div>
<body>
</html>