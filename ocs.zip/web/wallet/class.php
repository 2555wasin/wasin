<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="http://45.76.148.251/web/favicon.ico">
  <title>NIRAN-VPN</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.rawgit.com/suryadewa/Website/b1fd0e05/blue.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
   /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 15px;
    }
	    .bs-example{
    	margin: 15px;
    }
  </style>
</head> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">

<?php
$user ="ไม่ได้ใส่ รหัสผู้ใช้งาน";
$success = '<div align="center" class="alert alert-success">';
$iconok = '<i class="icon-ok"></i>';
$iconerror = '<i class="icon-remove"></i>';
$danger = '<div align="center" class="alert alert-danger">';
?>