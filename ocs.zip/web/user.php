

<?php
SESSION_START();
if(!$_SESSION['username']){
	header("location: wallet.html");
}

?>
<html>
<html lang="en">
<head>
<title>MMT-VPN.GA</title>
<link rel="stylesheet" href="https://bootswatch.com/3/darkly/bootstrap.min.css">
<link rel="shortcut icon" href="http://mmt-server.tk/images/vpn.png"/>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
</head>
<body>
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-8 col-md-offset-2 ver-center">
<form action="wallet.php" method="post">
	<div class="form-group">
	
		<center><h1><font color="#EE82EE">กรุณาใส่ </font><font color="#FF1493">หมายเลขอ้างอิง</font> <font color="#EE82EE">ในช่องด้านล่าง</font></h1>

<?php

include "config.php";


$sql = "select * from user where username='".$_SESSION['username']."'";
$query = mysqli_query($conn,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>

<h3 align="center"><font color="#33FF66"><b>ชื่อผู้ใช้งาน :  </b></font><font color="#FF3333"><?php echo $result['username'];?></font></h3>
  <h3 align="center"><font color="#3399FF"><b>เงินคงเหลือบัญชี้นี้:  </b></font><font color="#FF9933"><?php echo $result['saldo'];?> บาท</font></h3>
		<input type="text" class="form-control" maxlength="20" name="wallet" placeholder="หมายเลขอ้างอิง ตัวอย่าง เช่น ( 50000123456789 ) ">
	</div>
         <button class="btn btn-block btn btn-warning" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> กดเพื่อเติมเงิน</button>
		<a href="/web/wallet.html" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                   ย้อนกลับไปหน้าที่แล้ว</a>
</form>
<br /> 
<center><h4><font color="#6600CC">Truemoney Wallet Auto เพียงแค่ท่านนำหมายเลขอ้างอิงมาใส่เพียงเท่านั้น</font></h4>
<center><h4><font color="#FFCC00">โอนมายังเบอร์ </font><font color="#FF9933">wallet: 0902516190</font><font color="#FFCC00"> ( นิรันดร์ วงสีลา )</font></h4>
<center><h4><font color="#FF0000">กฎการเติมเงิน ห้ามเติมต่ำกว่า 10 บาทไม่งั้นระบบจะไม่สามารถเพิ่มเครดิตให้ท่านได้</font></h4>
<br /> 
<br /> 
</div>
</div>
<br /> 
<br /> 
<br /> 


<div id="image1" style="position:absolute; overflow:hidden; left:780px; top:470px; width:500px; height:900px; z-index:1"><img src="http://tmwallet.thaighost.net/images/transactionid.jpg" alt="" title="" border=0 width=350 height=400></div>

<div id="text1" style="position:absolute; overflow:hidden; left:330px; top:430px; width:448px; height:486px; z-index:1">
<div class="wpmd">
<h4> <font color="#FF9933">
<br /> 
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 10 =10 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 20 =20 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 30 =30 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 40 =40 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 50 =50 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 60 =60 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 70 =70 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 80 =80 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 90 =90 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 100 =100 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 200 =200 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 300 =300 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 400 =400 เครดิต</p></font></div>
<div align=center><font color="#FF9900"  class="ws22"><p>ราคาที่เติม 500 =500 เครดิต</p></font></div></h4>
</div></div>

    <style type="text/css">
<!--
body {

	background-image: url(http://mmt-server.tk/images/53999_prison_school.jpg);
	background-attachment: fixed;
	background-position: center top;
	margin: 0px;
	padding: 0px;
}
-->
</style>
<body>
</html>