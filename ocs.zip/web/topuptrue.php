

<?php
SESSION_START();
if(!$_SESSION['username']){
	header("location: truemoney.html");
}

?>
<html>
<head>
<title>เติมเงิน</title>

<script type="text/javascript" src='https://www.tmtopup.com/topup/3rdTopup.php?uid=1234'></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="row">
<form action="#" method="post">
	<div class="form-group">
		<h2>รหัสบัตรทรู 14 หลัก</h2>
		
        
     <input name="tmn_password" type="text" id="tmn_password" class="form-control"maxlength="14" />
	</div>
	
    <input type="button" value="เติมเงิน !" class="btn btn-theme btn-block"onclick="submit_tmnc()" />
    
</form>

<?php

include "config.php";


$sql = "select * from user where username='".$_SESSION['username']."'";
$query = mysqli_query($conn,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>

<p><b>ชื่อผู้ใช้ </b>			<?php echo $result['username'];?></p>
<p><b>Point</b>			<?php echo $result['saldo'];?></p>
</div>
<input type="hidden" value="<?php echo $result['username'] ;?>" id="ref1" name="ref1">&nbsp;
      <input type="hidden" value="<?php echo $result['email'] ;?>" id="ref2" name="ref2">
</div>
<body>
</html>