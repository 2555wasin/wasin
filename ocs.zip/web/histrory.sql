-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 03, 2018 at 10:01 AM
-- Server version: 5.5.59
-- PHP Version: 5.4.45-0+deb7u13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `VIP`
--

-- --------------------------------------------------------

--
-- Table structure for table `histrory`
--

CREATE TABLE IF NOT EXISTS `histrory` (
  `NumberWallet` varchar(14) NOT NULL,
  `money` float NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `histrory`
--

INSERT INTO `histrory` (`NumberWallet`, `money`, `username`, `status`, `id`) VALUES
('50000598534574', 1, 'bababa357', 1, 45),
('50000598534574', 1, 'bababa357', 1, 46),
('50000598534574', 1, 'bababa357', 1, 47),
('50000598534574', 1, 'bababa357', 1, 48),
('50000598534574', 1, 'bababa357', 1, 49),
('50000598534574', 1, 'bababa357', 1, 50),
('50000598534574', 1, 'bababa357', 1, 51),
('50000598534574', 1, 'bababa357', 1, 52),
('50000602590898', 10, 'test555', 1, 53),
('50000602611651', 10, 'test555', 1, 54),
('50000602718636', 10, 'Chai001', 1, 55),
('50000602914658', 100, 'Chai001', 1, 56),
('50000603347429', 10, 'beebright2316', 1, 57),
('50000603480492', 50, 'angkoon', 1, 58),
('50000604066629', 100, 'Yoobvpn2', 1, 59),
('50000604142143', 10, 'Chai001', 1, 60),
('50000607656035', 30, 'samrit', 1, 61),
('50000607680890', 20, 'samrit', 1, 62),
('50000607885619', 40, 'Soulight', 1, 63),
('50000609579079', 20, 'beebright2316', 1, 64),
('50000610669019', 50, 'Nasrulloh', 1, 65);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
