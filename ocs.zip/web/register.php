<?php
    $dbhost = 'localhost';
    $dbname = 'OCS_PANEL';  
    $dbuser = 'root';                  
    $dbpass = '13501'; 
    
    
    try{
        
        $dbcon = new PDO("mysql:host={$dbhost};dbname={$dbname}",$dbuser,$dbpass);
        $dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
    }catch(PDOException $ex){
        
        die($ex->getMessage());
    }
     
     if(isset($_POST['submit']))
  {
 $username=$_POST['username'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $hash = password_hash($password, PASSWORD_BCRYPT);
 try {
       $stmt = $dbcon->prepare("INSERT INTO user(username,email,password) VALUES(:username, :email, :password)");
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":password", $hash);
        $stmt->execute();
 }
    catch(PDOException $e){
      echo $e->getMessage();
 }
 echo 'สมัครสมาชิกเรียบร้อยแล้วครับ';
    }
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>ระบบลงทะเบียน</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2>ระบบลงทะเบียน THVPN.XYZ </h2>
  <div class="col-md-8">
  <form action ="register.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
      <label for="text">username:</label>
      <input type="text" class="form-control" name="username" id="email" placeholder="ไอดีเว็บไซต์">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" name="password" placeholder="Enter password">
    </div>
    <button type="submit" name="submit" class="btn btn-primary">สมัครสมาชิก</button>
	<a href="https://thvpn.xyz"><input type="button" value="LOGINWEB"></a>
	
	
  </form>
  </div>
</div>
</body>
</html>
</body>
</html>