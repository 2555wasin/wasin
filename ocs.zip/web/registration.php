  <title>BBG-01</title>
  <link rel="icon" href="/web/LOGO/lee.ico" type="image/x-icon" />

<style type="text/css">
body {
	background-image: url(https://wallpaperscraft.com/image/vocaloid_hatsune_miku_kimono_girl_tree_cherry_101010_1600x900.jpg);
}
</style>
<h1>&nbsp;</h1>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">

</p>
<form id="form1" name="form1" method="post" action="reg.php">
<div class="container" style=     "margin-bottom: 30px;">
	<div class="row">
		<div class="col-md-3"></div>
		     <div class="col-md-6" style="margin-top:70px;" >
          <div class="page-header">
                    <h1 align="center">สมัครสมาชิก</h1>
  </div>
			
								<div class="form-group">
					<label for="username">ชื่อผู้ใช้งาน</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="Username">
					<p class="help-block">กรุณากรอก 6 ตัวขึ้นไป ( ภาษาอังกฤษเท่านั้น )</p>
				</div>
				<div class="form-group">
					<label for="email">อีเมล์</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
					<p class="help-block">กรุณากรอก อีเมลล์ ของท่าน ( ไม่จำเป็นต้องมีอยู่จริงก็ได้ครับ )</p>
				</div>
				<div class="form-group">
					<label for="password">รหัสผ่าน</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Enter a password">
					<p class="help-block">ใส่ตัวเลข 6 หลักขึ้นไป</p>
				</div>
				<div class="form-group">
					<label for="password_confirm">ยืนยันรหัสผ่าน</label>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Confirm your password">
					<p class="help-block">ใส่รหัสผ่านอีกครั้ง</p>
				</div>
				  <div class="col-lg-12">

         <button class="btn btn-info btn-block" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> สมัครสมาชิก</button>
         <a href="/" class="btn btn-block btn btn-warning">
		 <i class="fa fa-ravelry">
		 </i>
                  กลับไปยังหน้าแรก</a>
				      <form id="form1" name="form1" method="post" action="">
              <div align="center"><b><p>© 2018 <a href="/">NIRAN-VPN</a> All Rights Reserved | Design BY <a href="https://www.facebook.com/ADMINMAZE">NIRAN WONGSEELA </a></b></p></div>
</form>
</div>
</form>
<?
include "class.php";
?>