<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">

<?php
$success = '<div align="center" class="alert alert-success">';
$iconok = '<i class="icon-ok"></i>';
$iconerror = '<i class="icon-remove"></i>';
$danger = '<div align="center" class="alert alert-danger">';
?>