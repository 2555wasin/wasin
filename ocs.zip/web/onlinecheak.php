<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0; bg-color:red">
        <div class="navbar-header">
          
            <a class="navbar-brand" href="/"><i class=""></i>VPN-THAI</a> <p class="navbar-text">บริการ VPN ราคาถูก</p>
        </div>
    </nav>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="http://45.76.148.251/web/favicon.ico">
  <title>Online User</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.rawgit.com/suryadewa/Website/b1fd0e05/blue.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
   /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 15px;
    }
	    .bs-example{
    	margin: 15px;
    }
  </style>
</head> 
<body>
<div class="jumbotron">
  <div class="container text-center">
    <h1>ระบบเช็คผู้ใช้งาน</h1>      
    <p>api-openvpn</p>
    <p>&nbsp;</p>
  </div>
</div>
  
<div class="bs-example">
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title">&nbsp;</h4>
                <form name="form1" method="post" action="chekz.php">
                  <p>
                    <label for="username"></label>
                  </p>
                  <p>
                    <label for="password"></label>
                  </p>
                  <div class="card-header" data-background-color="red">
                    <h4 class="title">API Server</h4>
                    <p class="category">Server SG-1</p>
                  </div>
                  <div class="card-content table-responsive">
                    <table class="table">
                      <?php
    $urlWithoutProtocol = "http://163.44.197.231:85/api.php";
    $request         = "";
    $isRequestHeader = false;
 
    $exHeaderInfoArr   = array();
    $exHeaderInfoArr[] = "Content-type: text/xml";
    $exHeaderInfoArr[] = "Authorization: "."Basic ".base64_encode("authen_user:authen_pwd");
 
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $urlWithoutProtocol);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
    curl_setopt($ch, CURLOPT_HEADER, (($isRequestHeader) ? 1 : 0));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if( is_array($exHeaderInfo) && !empty($exHeaderInfo) )
    {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $exHeaderInfo);
    }
    $response = curl_exec($ch);
    curl_close($ch);
 
    echo $response;
?>
                    </table>
                  </div>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </form>
                <h4 class="panel-title"><br>
                </h4>
            </div>
        </div>
    </div>
    <div class="row">

            <div class="col-xs-12">

                <footer>

                    <p align="center"> Copyright &copy; <a href="https://www.facebook.com/Jo.Guitar.za">panupong. </a>  All rights reserved...</p>

                </footer>
</div></div></div>
</body>
</html>
