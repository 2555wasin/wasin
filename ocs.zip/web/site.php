<?
header("location: /");
?>