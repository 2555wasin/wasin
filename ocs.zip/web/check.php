<?php
SESSION_START();
include 'config.php';

$user = $_POST['user'];

$sql = "select * from users where username='$user'";
$query = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($query);
if(isset($result)){
	$_SESSION['user'] = $result;
	header("location: user.php");
}else{
	echo ' <br><p><center><font color="red" size="24"><h3>!! �ô�����ͼ����ҹ���١��ͧ !!</h3></font></p>
<p><a href="/wallet/"><font size="24"><h3><u>��͹��Ѻ</u></h3></font></a></center></p> ';
}