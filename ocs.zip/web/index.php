<html>
<head>
<title>MMT-VPN.GA</title>
<link rel="stylesheet" href="https://bootswatch.com/3/darkly/bootstrap.min.css">
<link rel="shortcut icon" href="http://mmt-server.tk/images/vpn.png"/>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
</head>
<body>
</div>
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-8 col-md-offset-2 ver-center">
<form action="check.php" method="post">
	<div class="form-group">
  <br />
   <center>
   <h1><font color="#ff1a1a">ระบบเติมเงิน</font> <font color="#ffbb33">Auto </font><font color="#ff9933">True Wallet</font></h1>
   <h2><font color="#6600CC">กรุณาใส่ </font><font color="#FF3366">Username</font><font color="#6600CC">ของท่าน</font></h2>
   <h3><font color="#00e6e6"> เพื่อเข้าสู่การเติมเงิน</font></h3> </center>
  <br /> 
  <br /> 
		<input type="text" class="form-control" name="user" placeholder="กรุณาใส่ Usernameของท่าน ตัวอย่าง เช่น ( Ilikecat123 ) ">
	</div>
         <button class="btn btn-block btn btn-warning" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> เข้าสู่ระบบเติมเงิน</button>
		<a href="/" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                   ย้อนกลับไปหน้าแรก</a>
  <br /> 
  <br /> 
  <br /> 
    <br /> 
	  <br /> 
	
	</div>
</form>
</div> 
    <style type="text/css">
<!--
body {

	background-image: url(http://mmt-server.tk/images/53999_prison_school.jpg);
	background-attachment: fixed;
	background-position: center top;
	margin: 0px;
	padding: 0px;
}
-->
</style>
</div>
<body>

</html>