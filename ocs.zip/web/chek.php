<?php 
SESSION_START();
require_once("config.php");
include "class.php";
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	
	$sql = "select * from user where username = '".$username."'";
	$rs = mysqli_query($conn,$sql);
	$numRows = mysqli_num_rows($rs);
	
	if($numRows  == 1){
		$row = mysqli_fetch_assoc($rs);
		if(password_verify($password,$row['password'])){
                $_SESSION['username'] = $username;
                
			echo $success.'<h5>' .$iconok. ' Login Succes!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=user.php'>";
		}
		else{
			echo  $danger.'<h5>' .$iconerror. ' Password Wrong!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
		}
	}
	else{
		echo "No User found";
	
}