<?php
include "class.php";
//include "config.php";
	@mysql_connect("localhost","root","17072543n");
	mysql_select_db("OCS_PANEL");
	
	if(trim($_POST["username"]) == "")
	{
		echo  $danger.'<h5>' .$iconerror. ' ท่านไม่ได้ใส่ Username!</h5><h5>(ระบบกำลังพาท่านไป...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=registration.php'>";
		
		exit();	
	}
	
	
	if(trim($_POST["email"]) == "")
	{
		echo  $danger.'<h5>' .$iconerror. ' ท่านไม่ได้ใส่  Email!</h5><h5>(ระบบกำลังพาท่านไป...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=registration.php'>";
		exit();	
	}	
	if($_POST["password"] != $_POST["password_confirm"])
	{
		echo  $danger.'<h5>' .$iconerror. ' รหัสผ่านไม่ตรงกัน!</h5><h5>(ระบบกำลังพาท่านไป...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=registration.php'>";
		exit();
	}
	
	$strSQL = "SELECT * FROM user WHERE username = '".trim($_POST['username'])."' ";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	if($objResult)
	{
			echo  $danger.'<h5>' .$iconerror. ' มีชื่อผู้ใช้นี้แล้ว!</h5><h5>(ระบบกำลังพาท่านไป...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=registration.php'>";
	}
	else
	{	
		$options = array("cost"=>10);
		$hashPassword = password_hash($_POST["password"],PASSWORD_BCRYPT,$options);
	    $strSQL = "INSERT INTO user (username,password,email) VALUES ('".$_POST["username"]."', 
        '".$hashPassword."','".$_POST["email"]."')";
		$objQuery = mysql_query($strSQL);
		
		echo $success.'<h5>' .$iconok. ' สมัครสมาชิกสำเร็จ!</h5><h5>(ระบบกำลังพาท่านไป...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=/'>";		
	
		
		
	}

	mysql_close();
?>