<?php
SESSION_START();
include 'config.php';
include "class.php";


$walletmoney = $_POST['wallet'];

//Show all error, remove it once you finished you code.
ini_set('display_errors', 1);
//Include TrueWallet class.
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();
//Login with your username and password.

$username = "Nid1399@gmail.com";
$password = "Niran0902516190";
//Logout incase your previous session still exist, no need if you only use 1 user.
$wallet->logout();

//Login into TrueWallet
if($wallet->login($username,$password)){

	$profile = $wallet->get_profile();

	$transaction = $wallet->get_transactions();
	//�� ��͹��ѧ 10 �ѹ

	for($i = 0;$i < 10;$i++){

			$report = $wallet->get_report($transaction[$i]->reportID);

			$checkid = $report->section4->column2->cell1->value; //�Ţ�����ҧ�ԧ

			$money = $report->section3->column1->cell1->value; //�ӹǹ�Թ


			//���Ţ�����ҧ�Թ�Ѻ�ӹǹ�Թ����͹�� ������ç��͹� ���ʴ�    ��¡�üԴ��Ҵ�ͧ�����ա����
			if($walletmoney == $checkid && $money == 10){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
			echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";

					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 15){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 20){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 30){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 40){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 50){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 100){
				$sql = "select * from user where username='".$_SESSION['username']."'";
				$sqle = "select * from histrory where NumberWallet='$walletmoney'";
				$query = mysqli_query($conn,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ��� status �Ѻ�Ţ�����ҧ�ԧ �����
				if($result['status'] == ''){
					echo $success.'<h5>' .$iconok. ' Topup Succes! '.$money.' Bath</h5><h5>(Wait...)</h5></div>'."<meta     http-equiv='refresh'content='2 ;url=/'>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".                     $_SESSION['username']."',1)";
					mysqli_query($conn,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['username']."'";
					mysqli_query($conn,$sql1) or die; ('Error Query');
				}else{
					echo  $danger.'<h5>' .$iconerror. '  Duplicate reference!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=wallet.html'>";
				}
				break;
			}else{
				echo  $danger.'<h5>' .$iconerror. ' 
Reference No Wrong!</h5><h5>(Wait...)</h5></div>'."<meta http-equiv='refresh' content='2 ;url=user.php'>";
				break;
			}
	}

	//Logout
	$wallet->logout();
}else{
	echo 'Login Failed!';
}
?>
